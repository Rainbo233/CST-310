Allen Hall
CST-310
Professor Citro
16 October, 2022

-------------------------------------------------------------------------------------

Hey there Professor Citro, it's Allen again.
This is our updated project, where we added more leaves and 
got a camera working. Chris did the camera work, and the left side leaves, while I did the right side.

-------------------------------------------------------------------------------------

To run our program, it is very simple yet again. Simply go to the folder that this
file is in, and run the following commands:

$ g++ Project_Code.cpp -o PLANT -lGL -lglut -lGLU
$ ./PLANT

Make sure you have all the libraries listed in the first command installed,
which I have no doubt you already have. As always, there's a backup file for you to use in case it
doesn't compile correctly. Just have the same parameters as the first command when you run it.

-------------------------------------------------------------------------------------

Tried to get Shaders to work with no avail. The picture included is the one I'll be using for the texture once I get it working. I spent way too much time on trying to get textures to work, which is why there isn't as much done as I'd like. Next time you see this project, though, it'll be really good. Promise.

Have a good one!