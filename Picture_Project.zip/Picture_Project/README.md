Allen Hall
CST-310
Professor Citro
9 October, 2022

-------------------------------------------------------------------------------------

Hello Professor! This project was the building stages on creating our 
picture in OpenGL by focusing on primitives. It was very, VERY challenging to do
since I'm the kind of person to need to match it up 1 to 1, but I think what we have 
is pretty good.

The only thing really missing is all of the leaves on the stems, but those can be 
added in the next project along with the stuff in the shelves.

-------------------------------------------------------------------------------------

To run our program, it is very simple. Simply go to the folder that this
file is in, and run the following commands:

$ g++ Project_Code.cpp -o PLANT -lGL -lglut -lGLU
$ ./PLANT

Make sure you have all the libraries listed in the first command installed,
which I have no doubt you already have. Just in case this doesn't work,
there is a backup.txt file for you to use yourself. Just have the same parameters
as the first command when you run it.

-------------------------------------------------------------------------------------

Thank you, OpenGL is a very interesting tool to use, and I'm looking forward to working
on and seeing what the final product will look like. Already it's looking like the 
picture, which is really cool to see. Have a good day!